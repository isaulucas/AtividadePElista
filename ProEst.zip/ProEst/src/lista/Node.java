package lista;

public class Node {

    public Node prox;

    public String content;

}